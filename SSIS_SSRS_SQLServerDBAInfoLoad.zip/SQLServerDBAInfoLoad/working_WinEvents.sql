create table WinEventLogs (
	ComputerName nvarchar(255)
	, LogFile nvarchar(255)
	, Type nvarchar(255)
	, Message nvarchar(4000)
	, SourceName nvarchar(255)
	, TimeGenerated nvarchar(255)
	, TimeWritten nvarchar(255) )

truncate table WinEventLogs

xp_fixeddrives

select * from WinEventLogs order by 1, 6 desc  --Login failed for user 'APEX\mopeterson'. [CLIENT: 10.1.4.206]  

